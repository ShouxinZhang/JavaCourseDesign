public class Main {
    public static void main(String[] args) {
        EntropyCalculatorFrame test=new EntropyCalculatorFrame();
        test.setDefaultCloseOperation(EntropyCalculatorFrame.EXIT_ON_CLOSE);
    }
}